# Auth module for handling user authentication
