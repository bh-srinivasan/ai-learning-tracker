# Admin module for user and course management
