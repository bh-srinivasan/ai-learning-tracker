#!/bin/bash
echo "Starting minimal AI Learning Tracker..."
cd /home/site/wwwroot
python app_minimal.py
