# Recommendations module
from .routes import bp
