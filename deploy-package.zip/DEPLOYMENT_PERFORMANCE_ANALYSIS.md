# 🚀 Azure App Service Deployment Performance Analysis

## **Diagnosis**

Based on the deployment logs and repository analysis:

• **85% of deployment time** is spent in **server-side build phase** (~2.5+ minutes)
• **15% of deployment time** is in **Git transfer** (~10-15 seconds)  
• **Primary bottleneck**: Kudu/Oryx rebuilding Python dependencies from scratch every deployment
• **Secondary issues**: Large binary files (SQLite DBs, logs) in Git history increasing transfer size
• **Configuration issue**: `SCM_DO_BUILD_DURING_DEPLOYMENT=true` forces server-side builds

### Time Breakdown from Last Deployment:
```
Git Transfer:        ~15 seconds  (15%)
Platform Detection:  ~20 seconds  (13%)  
Virtual Env Setup:   ~20 seconds  (13%)
pip install:         ~90 seconds  (60%) ⚠️ MAJOR BOTTLENECK
File Operations:     ~40 seconds  (27%)
Total:              ~185 seconds  (3+ minutes)
```

## **Top Fixes (Priority Order)**

### 🎯 **Fix #1: Switch to Zip Deploy + Run From Package** 
**Expected improvement: 5+ minutes → 30 seconds (90% faster)**

```bash
# Enable Run From Package mode
az webapp config appsettings set --name ai-learning-tracker-bharath --resource-group ai-learning-rg --settings WEBSITE_RUN_FROM_PACKAGE=1

# Disable server-side builds
az webapp config appsettings set --name ai-learning-tracker-bharath --resource-group ai-learning-rg --settings SCM_DO_BUILD_DURING_DEPLOYMENT=false

# Create deployment script for local build + zip deploy
cat > deploy-fast.ps1 << 'EOF'
# Build locally and deploy as package
Write-Host "Building locally..." -ForegroundColor Green
pip install -r requirements.txt --target ./package
Copy-Item *.py ./package/
Copy-Item -Recurse templates ./package/
Copy-Item -Recurse static ./package/
Copy-Item -Recurse auth ./package/
Copy-Item -Recurse dashboard ./package/
Copy-Item -Recurse learnings ./package/
Copy-Item -Recurse courses ./package/
Copy-Item -Recurse admin ./package/
Copy-Item -Recurse recommendations ./package/
Copy-Item -Recurse db ./package/

Write-Host "Creating deployment package..." -ForegroundColor Green
Compress-Archive -Path ./package/* -DestinationPath app-deploy.zip -Force

Write-Host "Deploying to Azure..." -ForegroundColor Green
az webapp deployment source config-zip --name ai-learning-tracker-bharath --resource-group ai-learning-rg --src app-deploy.zip

Write-Host "Cleaning up..." -ForegroundColor Green
Remove-Item -Recurse ./package -Force
Remove-Item app-deploy.zip -Force
Write-Host "✅ Fast deployment complete!" -ForegroundColor Green
EOF

# Make script executable and run
powershell ./deploy-fast.ps1
```

### 🎯 **Fix #2: Repository Optimization** 
**Expected improvement: 50% faster Git transfer**

```bash
# Remove large binary files from Git tracking
echo "*.db" >> .gitignore
echo "*.zip" >> .gitignore
echo "logs/" >> .gitignore
echo "__pycache__/" >> .gitignore
echo "*.pyc" >> .gitignore

# Remove existing large files from Git history (CAREFUL - rewrites history)
git rm --cached *.db *.zip 2>/dev/null || true
git rm -r --cached logs/ 2>/dev/null || true

# Optimize repository
git gc --aggressive --prune=now
git repack -ad

# Commit optimizations
git add .gitignore
git commit -m "chore: optimize repository - remove large binaries, add gitignore"

# Push optimized repo (this push will still be slow, but subsequent ones will be fast)
git push origin master
```

### 🎯 **Fix #3: GitHub Actions CI/CD (Long-term solution)**
**Expected improvement: Near-instant deploys + build caching**

```yaml
# .github/workflows/azure-deploy.yml
name: Deploy to Azure App Service

on:
  push:
    branches: [ master ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.9'
        cache: 'pip'
    
    - name: Install dependencies
      run: |
        pip install -r requirements.txt --target ./package
        cp -r *.py templates/ static/ auth/ dashboard/ learnings/ courses/ admin/ recommendations/ db/ ./package/
    
    - name: Deploy to Azure
      uses: azure/webapps-deploy@v2
      with:
        app-name: ai-learning-tracker-bharath
        slot-name: production
        publish-profile: ${{ secrets.AZURE_WEBAPP_PUBLISH_PROFILE }}
        package: ./package
```

## **If Staying on `git push` (Quick Fixes)**

### Disable server-side builds (if you're pushing built artifacts):
```bash
az webapp config appsettings set --name ai-learning-tracker-bharath --resource-group ai-learning-rg --settings SCM_DO_BUILD_DURING_DEPLOYMENT=false
```

### Optimize pip installs:
```bash
# Add to requirements.txt comments
# --index-url https://pypi.org/simple/
# --trusted-host pypi.org
# --cache-dir /tmp/pip-cache

# Or set environment variable
az webapp config appsettings set --name ai-learning-tracker-bharath --resource-group ai-learning-rg --settings PIP_CACHE_DIR=/tmp/pip-cache
```

### Repository compression:
```bash
git gc --aggressive
git push azure master
```

## **Fast Path (3-5 Commands)**

```bash
# 1. Enable run from package mode
az webapp config appsettings set --name ai-learning-tracker-bharath --resource-group ai-learning-rg --settings WEBSITE_RUN_FROM_PACKAGE=1 SCM_DO_BUILD_DURING_DEPLOYMENT=false

# 2. Create simple zip deploy script
echo 'Compress-Archive -Path . -DestinationPath deploy.zip -Force -Exclude .git,__pycache__,*.pyc,.venv; az webapp deployment source config-zip --name ai-learning-tracker-bharath --resource-group ai-learning-rg --src deploy.zip; Remove-Item deploy.zip' > quick-deploy.ps1

# 3. Deploy now
powershell ./quick-deploy.ps1

# Expected result: 5+ minutes → 30-60 seconds
```

## **Risk/Impact Assessment**

| Change | Risk | Impact | Mitigation |
|--------|------|--------|------------|
| Zip Deploy + Run From Package | Low | High speed improvement | Test staging slot first |
| Repository cleanup | Medium | Rewrites Git history | Create backup branch first |
| Remove large files | Low | Smaller transfers | Files can be re-added if needed |
| GitHub Actions | Low | Better CI/CD pipeline | Keep git push as fallback |

## **Verification Checklist**

After implementing fixes:

- [ ] Deployment time < 60 seconds
- [ ] `git count-objects -vH` shows total size < 50MB  
- [ ] `WEBSITE_RUN_FROM_PACKAGE=1` in app settings
- [ ] `SCM_DO_BUILD_DURING_DEPLOYMENT=false` in app settings
- [ ] No `*.db`, `*.zip` files in new commits
- [ ] App starts successfully after deployment
- [ ] All routes functional (test admin courses page)

## **Expected Performance After Fixes**

| Method | Before | After | Improvement |
|--------|--------|-------|-------------|
| git push azure master | 5+ minutes | 30-60 seconds | 85% faster |
| Zip deploy | N/A | 20-30 seconds | Fastest |
| GitHub Actions | N/A | 2-3 minutes total | Best for teams |

**Bottom line**: Switch to Zip Deploy + Run From Package for immediate 90% improvement, then consider GitHub Actions for long-term CI/CD benefits.
