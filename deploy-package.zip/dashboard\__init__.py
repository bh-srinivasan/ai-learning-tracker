# Dashboard module for user views
